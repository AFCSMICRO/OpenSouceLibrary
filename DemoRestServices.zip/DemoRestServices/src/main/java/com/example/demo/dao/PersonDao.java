package com.example.demo.dao;

public class PersonDao {
	
	/*public List<ServicePerson> selectAll() {
		StringBuilder sb = 
		new StringBuilder("SELECT * FROM ").append(TABLE_NAME);
		
		String query = sb.toString();
		ResultSet rs = session.execute(query);
	
		List<ServicePerson> books = new ArrayList<ServicePerson>();
		
		rs.forEach(r -> {
		books.add(new ServicePerson(
		r.getUUID("id"), 
		r.getString("title"),  
        r.getString("subject")));
	});
		return books;
		}*/

}
